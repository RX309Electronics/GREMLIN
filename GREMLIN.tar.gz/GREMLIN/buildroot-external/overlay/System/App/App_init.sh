#!/bin/bash

pip install pygame
wget https://github.com/RX309Electronics/Dvd-Logo-V2.0/archive/refs/heads/main.zip
unzip main.zip
cd Dvd-Logo-V2.0-main/DVD-logo/
sleep 1
python3 Main.py
